package annotation.entity;

public interface RareRailway {
    public  String[] Type_OF_RESERVATION={"Ac","NonAC"};
    public double[] RATE_OF_RESERVATION={100,60};
}
